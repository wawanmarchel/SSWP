from django.db import models


class Doctor(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    date_of_birth = models.DateField()
    date_of_death = models.DateField('Died', null=True, blank=True)
    gender = models.CharField(max_length=6)    

    def __str__(self):
        return f'{self.last_name},{self.first_name}'


class Patient(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=6)
    def __str__(self):
        return f'{self.last_name},{self.first_name},{self.date_of_birth},{self.gender}'


class Medicine(models.Model):
    medicine_name = models.CharField(max_length=30)
    medicine_price = models.IntegerField()

    def __str__(self):
        return self.medicine_name 