from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('doctors/', views.list_doctors, name='doctors'),
    path('doctor/add', views.add_doctor, name='add_doctor'),
    path('doctor/edit/<int:doctor_id>', views.edit_doctor, name='edit_doctor'),
    path('doctor/delete/<int:doctor_id>', views.delete_doctor, name='delete_doctor'),
    path('patients/', views.list_patients, name='patients'),
    path('patient/add', views.add_patient, name='add_patient'),
    path('patient/edit/<int:patient_id>', views.edit_patient, name='edit_patient'),
    path('patient/delete/<int:patient_id>', views.delete_patient, name='delete_patient'),
    path('medicines/', views.list_medicines, name='medicines'),
    path('medicine/add', views.add_medicine, name='add_medicine'),
    path('medicine/edit/<int:medicine_id>', views.edit_medicine, name='edit_medicine'),
    path('medicine/delete/<int:medicine_id>', views.delete_medicine, name='delete_medicine'),
]
