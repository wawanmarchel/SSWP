from django.forms import ModelForm
from django.core.exceptions import ValidationError
from catalog.models import Doctor, Patient, Medicine


class DoctorForm(ModelForm):
    class Meta:
        model = Doctor  # model to use in form
        # list of fields to be displayed
        fields = ['first_name', 'last_name', 'date_of_birth', 'date_of_death','gender']


class PatientForm(ModelForm):
    class Meta:
        model = Patient  # model to use in form
        # list of fields to be displayed
        fields = ['first_name', 'last_name', 'date_of_birth', 'gender']

class MedicineForm(ModelForm):
    class Meta:
        model = Medicine

        fields= ['medicine_name','medicine_price']