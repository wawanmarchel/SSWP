from django.forms.models import model_to_dict
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from catalog.models import Doctor, Patient, Medicine
from catalog.forms import DoctorForm, PatientForm, MedicineForm




def index(request):
    # get all info here including authors, books, and genres
    num_doctors = Doctor.objects.all().count()
    num_patients = Patient.objects.all().count()
    num_medicines = Medicine.objects.all().count()
    context = {
        'num_doctors': num_doctors,
        'num_patients': num_patients,
        'num_medicines': num_medicines,
    }
    return render(request, 'index.html', context=context)


def list_doctors(request):
    doctors = Doctor.objects.all()
    context = {
        'doctors': doctors,
    }
    return render(request, 'doctors.html', context=context)


def list_patients(request):
    patients = Patient.objects.all()
    context = {
        'patients': patients,
    }
    return render(request, 'patients.html', context=context)


def list_medicines(request):
    medicines = Medicine.objects.all()
    context = {
        'medicines': medicines,
    }
    return render(request, 'medicines.html', context=context)


def add_doctor(request):
    if request.method == 'POST':
        form = DoctorForm(request.POST)
        if form.is_valid():
            form.save()  # directly save the form
            return HttpResponseRedirect(reverse('doctors'))
    else:
        form = DoctorForm()

    context = {
        'form': form
    }
    return render(request, 'doctor_form.html', context=context)


def edit_doctor(request, doctor_id):
    if request.method == 'POST':
        doctor = Doctor.objects.get(pk=doctor_id)
        form = DoctorForm(request.POST, instance=doctor)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('doctors'))
    else:
        doctor = Doctor.objects.get(pk=doctor_id)
        fields = model_to_dict(doctor)
        form = DoctorForm(initial=fields, instance=doctor)
    context = {
        'form': form,
        'type': 'edit',
    }
    return render(request, 'doctor_form.html', context=context)


def delete_doctor(request, doctor_id):
    doctor = Doctor.objects.get(pk=doctor_id)
    if request.method == 'POST':
        doctor.delete()
        return HttpResponseRedirect(reverse('doctors'))
    context = {
        'doctor': doctor
    }
    return render(request, 'doctor_delete_form.html', context=context)


def add_patient(request):
    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            form.save()  # directly save the form
            return HttpResponseRedirect(reverse('patients'))
    else:
        form = PatientForm()

    context = {
        'form': form
    }
    return render(request, 'patient_form.html', context=context)


def edit_patient(request, patient_id):
    if request.method == 'POST':
        patient = Patient.objects.get(pk=patient_id)
        form = PatientForm(request.POST, instance=patient)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('patients'))
    else:
        patient = Patient.objects.get(pk=patient_id)
        fields = model_to_dict(patient)
        form = PatientForm(initial=fields, instance=patient)
    context = {
        'form': form,
        'type': 'edit',
    }
    return render(request, 'patient_form.html', context=context)


def delete_patient(request, patient_id):
    patient = Patient.objects.get(pk=patient_id)
    if request.method == 'POST':
        patient.delete()
        return HttpResponseRedirect(reverse('patients'))
    context = {
        'patient': patient,
    }
    return render(request, 'patient_delete_form.html', context=context)

def add_medicine(request):
    if request.method == 'POST':
        form = MedicineForm(request.POST)
        if form.is_valid():
            form.save()  # directly save the form
            return HttpResponseRedirect(reverse('medicines'))
    else:
        form = MedicineForm()

    context = {
        'form': form
    }
    return render(request, 'medicine_form.html', context=context)


def edit_medicine(request, medicine_id):
    if request.method == 'POST':
        medicine = Medicine.objects.get(pk=medicine_id)
        form = MedicineForm(request.POST, instance=medicine)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('medicines'))
    else:
        medicine = Medicine.objects.get(pk=medicine_id)
        fields = model_to_dict(medicine)
        form = MedicineForm(initial=fields, instance=medicine)
    context = {
        'form': form,
        'type': 'edit',
    }
    return render(request, 'medicine_form.html', context=context)


def delete_medicine(request, medicine_id):
    medicine = Medicine.objects.get(pk=medicine_id)
    if request.method == 'POST':
        medicine.delete()
        return HttpResponseRedirect(reverse('medicines'))
    context = {
        'medicine': medicine,
    }
    return render(request, 'medicine_delete_form.html', context=context)

