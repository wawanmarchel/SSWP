from django.contrib import admin
from .models import Doctor , Patient , Medicine


admin.site.register(Doctor)
admin.site.register(Patient)
admin.site.register(Medicine)
